package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "NotePrefs";
    private static final String KEY_NOTE_COUNT = "NoteCount";
    private LinearLayout notesContainer;
    private List<Note> noteList;
    private String category;
    private EditText searchEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        notesContainer = findViewById(R.id.notesContainer);
        Button saveButton = findViewById(R.id.saveButton);
        Button searchButton = findViewById(R.id.searchButton);


        noteList = new ArrayList<>();

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveNote();
            }
        });

        searchEditText = findViewById(R.id.searchEditText);

        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String query = searchEditText.getText().toString();
                performSearch(query);
            }
        });


        loadNotesFromPreferences();
        displayNotes();
    }


    private void displayNotes() {
        for (Note note : noteList) {
            createNoteView(note);
        }
    }

    private void loadNotesFromPreferences() {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        int noteCount = sharedPreferences.getInt(KEY_NOTE_COUNT, 0);

        for (int i = 0; i < noteCount; i++) {
            String title = sharedPreferences.getString("note_title_" + i, "");
            String content = sharedPreferences.getString("note_content_" + i, "");
            String category = sharedPreferences.getString("note_category_" + i, "");

            Note note = new Note();
            note.setTitle(title);
            note.setContent(content);
            note.setCategory(category);

            noteList.add(note);
        }
    }

    private void saveNote() {
        EditText titleEditText = findViewById(R.id.titleEditText);
        EditText contentEditText = findViewById(R.id.contentEditText);
        EditText categoryEditText = findViewById(R.id.categoryEditText);

        String category = categoryEditText.getText().toString();
        String title = titleEditText.getText().toString();
        String content = contentEditText.getText().toString();

        if (!title.isEmpty() && !content.isEmpty()) {
            Note note = new Note();
            note.setTitle(title);
            note.setContent(content);
            note.setCategory(category);

            noteList.add(note);
            saveNotesToPreferences();

            createNoteView(note);
            clearInputFields();
        }
    }

    private void clearInputFields() {
        EditText titleEditText = findViewById(R.id.titleEditText);
        EditText contentEditText = findViewById(R.id.contentEditText);
        EditText categoryEditText = findViewById(R.id.categoryEditText);

        titleEditText.getText().clear();
        contentEditText.getText().clear();
        categoryEditText.getText().clear();
    }

    private void createNoteView(final Note note) {
        View noteView = getLayoutInflater().inflate(R.layout.note_item,null);
        TextView titleTextView = noteView.findViewById(R.id.titleTextView);
        TextView contentTextView = noteView.findViewById(R.id.contentTextView);
        TextView categoryTextView = noteView.findViewById(R.id.categoryTextView);

        titleTextView.setText(note.getTitle());
        contentTextView.setText(note.getContent());
        categoryTextView.setText(note.getCategory());

        setLongClickListener(noteView, note);

        notesContainer.addView(noteView);
    }

    private void setLongClickListener(final View noteView, final Note note) {
        noteView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                showEditOrDeleteDialog(note);
                return true;
            }
        });
    }

    private void showEditOrDeleteDialog(final Note note) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Options");
        String[] options = {"Edit", "Delete"};
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (which == 0) {
                    showEditDialog(note);
                } else if (which == 1) {
                    showDeleteDialog(note);
                }
            }
        });
        builder.show();
    }
    private void showEditDialog(final Note note) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Note");
        View viewInflated = getLayoutInflater().inflate(R.layout.edit_note_dialog, null);
        builder.setView(viewInflated);

        final EditText titleEditText = viewInflated.findViewById(R.id.titleEditText);
        final EditText contentEditText = viewInflated.findViewById(R.id.contentEditText);
        final EditText categoryEditText = viewInflated.findViewById(R.id.categoryEditText);

        titleEditText.setText(note.getTitle());
        contentEditText.setText(note.getContent());
        categoryEditText.setText(note.getCategory());

        builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String newTitle = titleEditText.getText().toString();
                String newContent = contentEditText.getText().toString();
                String newCategory = categoryEditText.getText().toString();

                // แก้ไขข้อมูลใน note และบันทึกลง SharedPreferences
                note.setTitle(newTitle);
                note.setContent(newContent);
                note.setCategory(newCategory);
                saveNotesToPreferences();

                // รีเฟรชหน้าจอเพื่อแสดงข้อมูลใหม่
                refreshNoteViews();
            }
        });
        builder.setNegativeButton(android.R.string.cancel, null);

        builder.show();
    }

    private void showDeleteDialog(final Note note) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Note");
        builder.setMessage("Are you sure you want to delete this note?");
        builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                deleteNoteAndRefresh(note);
            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void deleteNoteAndRefresh(Note note) {
        noteList.remove(note);
        saveNotesToPreferences();
        refreshNoteViews();
    }

    private void refreshNoteViews() {
        notesContainer.removeAllViews();
        displayNotes();
    }

    private void saveNotesToPreferences() {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putInt(KEY_NOTE_COUNT, noteList.size());
        for (int i = 0; i < noteList.size(); i ++) {
            Note note = noteList.get(i);
            editor.putString("note_title_" + i, note.getTitle());
            editor.putString("note_content_" + i, note.getContent());
            editor.putString("note_category_" + i, note.getCategory());
        }
        editor.apply();
    }

    private void searchNotes(String query) {
        List<Note> searchResult = new ArrayList<>();

        for (Note note : noteList) {
            String title = note.getTitle().toLowerCase();
            String content = note.getContent().toLowerCase();
            String category = note.getCategory().toLowerCase();

            if (title.startsWith(query) || content.startsWith(query) || category.startsWith(query)) {
                searchResult.add(note);
            }
        }

        if (searchResult.isEmpty()) {
            showAlert("No results found.");
        } else {
            displaySearchResult(searchResult);
        }
    }

    private void showAlert(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    private void displaySearchResult(List<Note> searchResult) {
        notesContainer.removeAllViews();

        for (Note note : searchResult) {
            createNoteView(note);
        }
    }

    private void performSearch(String query) {
        if (query.length() >= 1) {
            searchNotes(query);
        } else {
            refreshNoteViews();
        }
    }
}
