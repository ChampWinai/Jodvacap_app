package com.example.myapplication;

public class Note {
    private String title;
    private String content;
    private String category;

    public Note() {

    }
    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }


    public Note(String title, String content, String category) {
        this.title = title;
        this.content = content;
        this.category = category;
    }
    public Note(String title, String content) {
        this.title = title;
        this.content = content;
        this.category = "";
    }
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

}

